## The front-end UI for the debug menu, primarily handles organizing them into groups and displaying those groups
class_name DebugMenuUI extends MarginContainer

## class that contains structured data needed to make the groups work
class DebugMenuGroup:
	var id: StringName ## unique ID and doubles as the display name
	var root_node: Node ## the highest-tier node of this specific group
	var container_node: Node ## the container that should have the DebugMenuItems in it
	
	## build a new one with the mandatory variables
	func _init(_id: StringName, _root_node: Node, _container_node: Node) -> void:
		id = _id
		root_node = _root_node
		container_node = _container_node

var my_groups: Array[DebugMenuGroup] ## array that contains each group to look through as needed

## checks the constant in DebugMenu to see if the FPS counter should be visible or not
func _ready() -> void:
	%FpsCounter.visible = DebugMenu.DEFAULT_FPS_COUNTER

## if the FPS counter is visible, update its value every frame
func _process(_delta: float) -> void:
	if Input.is_key_pressed(DebugMenu.TOGGLE_INPUT_MAP):
		visible = !visible
	
	if %FpsCounter.visible:
		%FpsLabel.text = str(Engine.get_frames_per_second())

## generic code to add any debug item, will create a new group if one is specified that doesn't exist.
## the default group exists in the scene already as a container, this basically adds it to the array
## the first time an item is added (it has no title so it's a bit different)
func add_debug_item(new_debug_item: DebugMenuItem, group_id: StringName = "Default") -> void:
	if group_id == "Default":
		var _default_group = DebugMenuGroup.new("Default", %DefaultGroup, %DefaultGroup)
		my_groups.append(_default_group)
	else:
		_add_debug_group_if_needed(group_id)
	
	var _target_group = get_debug_group_or_null(group_id)
	_target_group.container_node.add_child(new_debug_item)


## if the group doesn't exist, create the structure, add it to the array, and move it to the right spot
func _add_debug_group_if_needed(id: StringName):
	if get_debug_group_or_null(id): return
	var _new_root_node = %GroupTemplate.duplicate()
	%MainContainer.add_child(_new_root_node)
	_new_root_node.get_child(1).text = "____ %s" % id
	_new_root_node.show()
	var _new_debug_group = DebugMenuGroup.new(id, _new_root_node, _new_root_node.get_child(2))
	my_groups.append(_new_debug_group)

## returns the first group it finds with that specified ID, or returns null if there is none
func get_debug_group_or_null(id: StringName):
	for _group in my_groups:
		if _group.id == id:
			return _group
	return null

## simply turns on or off the FPS Counter, though its state is likely to already be in its desired mode
func set_fps_counter_visibility(_visible: bool) -> void:
	%FpsCounter.visible = _visible
