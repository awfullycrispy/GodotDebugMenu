## Must be added as a named global autoload called DebugMenu. Make sure to update the variables in the block below
extends Node

# these settings can be changes as desired
const TOGGLE_INPUT_MAP: Key = KEY_QUOTELEFT ## action name on the input map that will be used to toggle the menu on/off
const DEFAULT_MENU_VISIBLE = false ## if set to true, menu will be visible immediately upon spawning in
const DEFAULT_FPS_COUNTER = true ## if set to true, the FPS counter will be shown by default without running show_fps_counter()
const FOLDER_PATH = "res://addons/debug_menu/"

# if the debug_menu folder is kept somewhere other than addons, put the paths here
var _loaded_ui_scene = preload(FOLDER_PATH + "debug_menu_ui.tscn") ## needs the path to the file debug_menu_ui.tscn
var _loaded_item_scene = preload(FOLDER_PATH + "debug_menu_item.tscn") ## needs the path to the file debug_menu_item.tscn

# these variables are used in the code and should not be changed
var menu_in_tree: bool = false ## if true, the debug menu UI is loaded in the tree right now
var menu_ui: Node ## the latest debug menu UI node
var debug_menu_items: Array[DebugMenuItem] ## contains all debug items that should exist in the menu at the moment

## need to build the menu so it could be used as an FPS counter without having to add an item explicitly
func _ready() -> void:
	if DEFAULT_FPS_COUNTER:
		setup_menu_if_needed()

## Create the data needed for a new viewing item and pass the remaining duties to menu_ui
## this method can support any property that can be converted to a string
func add_viewing_item(id: StringName, target_node: Node, property: StringName, group_id: StringName = "Default") -> void:
	if !OS.is_debug_build(): return
	setup_menu_if_needed()
	var _new_debug_item = _loaded_item_scene.instantiate()
	_new_debug_item.setup(id, target_node, property, DebugMenuItem.DebugItemType.VIEWING)
	debug_menu_items.append(_new_debug_item)
	_new_debug_item.debug_item_removed.connect(_on_debug_item_removed)
	menu_ui.add_debug_item(_new_debug_item, group_id)

## same as viewing item but with different required properties, and runs set_range_values()
## this method only supports int and float properties
func add_range_item(id:StringName, target_node:Node, property:StringName, min:float, max:float, step:float, group_id:StringName = "Default") -> void:
	if !OS.is_debug_build(): return
	setup_menu_if_needed()
	var _new_debug_item = _loaded_item_scene.instantiate()
	_new_debug_item.setup(id, target_node, property, DebugMenuItem.DebugItemType.RANGE)
	_new_debug_item.set_range_values(min, max, step)
	debug_menu_items.append(_new_debug_item)
	_new_debug_item.debug_item_removed.connect(_on_debug_item_removed)
	menu_ui.add_debug_item(_new_debug_item, group_id)

## basically the same as viewing item but passes a different DebugItemType
## this method only supports bool properties
func add_toggle_item(id: StringName, target_node: Node, property: StringName, group_id: StringName = "Default") -> void:
	if !OS.is_debug_build(): return
	setup_menu_if_needed()
	var _new_debug_item = _loaded_item_scene.instantiate()
	_new_debug_item.setup(id, target_node, property, DebugMenuItem.DebugItemType.TOGGLE)
	debug_menu_items.append(_new_debug_item)
	_new_debug_item.debug_item_removed.connect(_on_debug_item_removed)
	menu_ui.add_debug_item(_new_debug_item, group_id)

## basically the same as viewing item but passes a different DebugItemType, and renames property to
## method, though the DebugMenuItem will still store it in "property" to simplify code
## this method only supports callables that have no mandatory arguments, and it cannot pass arguments
func add_trigger_item(id: StringName, target_node: Node, method: StringName, group_id: StringName = "Default") -> void:
	if !OS.is_debug_build(): return
	setup_menu_if_needed()
	var _new_debug_item = _loaded_item_scene.instantiate()
	_new_debug_item.setup(id, target_node, method, DebugMenuItem.DebugItemType.TRIGGER)
	debug_menu_items.append(_new_debug_item)
	_new_debug_item.debug_item_removed.connect(_on_debug_item_removed)
	menu_ui.add_debug_item(_new_debug_item, group_id)

## If the FPS counter is not visible, show it
func show_fps_counter() -> void:
	setup_menu_if_needed()
	menu_ui.set_fps_counter_visibility.call_deferred(true)

## If the FPS counter is visible, hide it
func hide_fps_counter() -> void:
	menu_ui.set_fps_counter_visibility(false)

## if there is no menu, it will be instantiated and setup here. Otherwise do nothing
func setup_menu_if_needed() -> void:
	if !menu_in_tree:
		menu_ui = _loaded_ui_scene.instantiate()
		menu_ui.visible = DEFAULT_MENU_VISIBLE
		get_tree().root.add_child.call_deferred(menu_ui)
		menu_ui.tree_exited.connect(_on_menu_ui_exiting_tree)
		menu_in_tree = true

## triggered when any debug item removes itself (in the case of its monitoring node is deleted)
## so the item can be removed from the array
func _on_debug_item_removed(item: DebugMenuItem) -> void:
	var _i = debug_menu_items.find(item)
	if _i != -1:
		debug_menu_items.remove_at(_i)

## triggered when the menu UI node leaves the tree for some reason, this will clear
## any existing items and make sure a new menu is made later
func _on_menu_ui_exiting_tree() -> void:
	menu_in_tree = false
	debug_menu_items.clear()
