## The items contained in the DebugMenuUI in charge of organizing/changing data as needed
## and are added by the DebugMenu global autoload (debug_menu.gd)
class_name DebugMenuItem extends HBoxContainer

## triggered upon exiting tree to remove this item from DebugMenu's array, this is connected by DebugMenu
signal debug_item_removed(item: DebugMenuItem)

## functionality that this item has
enum DebugItemType {
	VIEWING, ## no control, simply displays and updates a value. Should support most variable types
	RANGE, ## uses any Range node to edit a value live. Only supports int and float
	TRIGGER, ## uses a button to trigger a callable, only supports callables without mandatory parameters
	TOGGLE ## uses a button to turn a boolean on or off
}

var id: StringName ## name useed to identify the item
var target_node: Node ## node the item will be looking at
var property: StringName ## variable or callable the target node has
var type: DebugItemType ## holds the type and is used to build the node
var target_node_path: NodePath ## automatically created from the target_node on initialization
var _update_viewing_label := true ## set to false on types that remove the viewing label like toggle buttons

var _range_is_being_dragged: bool = false ## set to true while slider is being dragged so it cannot clash with the property on target_node
var range_max:float ## value is set by DebugMenu, and the range node references this value later
var range_min:float ## value is set by DebugMenu, and the range node references this value later
var range_step:float ## value is set by DebugMenu, and the range node references this value later

## called by DebugMenu to set all of the basic properties which are required by any type
func setup(_id: StringName, _target_node: Node, _property: StringName, _type: DebugItemType) -> void:
	id = _id
	target_node = _target_node
	property = _property
	type = _type
	target_node_path = _target_node.get_path()

## called by DebugMenu immediately after setup() to add all of the required
func set_range_values(_max:float, _min:float, _step:float) -> void:
	range_max = _max
	range_min = _min
	range_step = _step

## removes unneeded nodes and performs other setup as needed by its type
func _ready() -> void:
	match type:
		DebugItemType.VIEWING:
			%RangeHSlider.queue_free()
			%TriggerButton.queue_free()
			%ToggleButton.queue_free()
		DebugItemType.RANGE:
			%TriggerButton.queue_free()
			%ToggleButton.queue_free()
		DebugItemType.TRIGGER:
			_update_viewing_label = false
			%ViewingLabelSpacer.queue_free()
			%ViewingLabel.queue_free()
			%RangeHSlider.queue_free()
			%ToggleButton.queue_free()
		DebugItemType.TOGGLE:
			_update_viewing_label = false
			%ViewingLabelSpacer.queue_free()
			%ViewingLabel.queue_free()
			%RangeHSlider.queue_free()
			%TriggerButton.queue_free()
	update()
	%Title.text = id

## if the node it's monitoring is gone, remove yourself. otherwise, update your data
func _process(_delta: float) -> void:
	if !get_tree().root.has_node(target_node_path):
		debug_item_removed.emit(self)
		queue_free()
	elif visible:
		update()

## all of the code that needs to run each frame and on ready when the item is visible
func update() -> void:
	if _update_viewing_label:
		%ViewingLabel.text = str(target_node.get(property))
	
	match type:
		DebugItemType.RANGE:
			if !_range_is_being_dragged:
				%RangeHSlider.value = float(target_node.get(property))
			else:
				%ViewingLabel.text = str(%RangeHSlider.value)
		DebugItemType.TOGGLE:
			%ToggleButton.set_pressed_no_signal(target_node.get(property))

## sets this value to true, otherwise the value being pulled from the node and the
## slider's changing value will clash with one another
func _on_range_h_slider_drag_started() -> void:
	_range_is_being_dragged = true

## once the drag is finished, send the new value to the node in question. Since this can
## support int values too, it will check the target property and convert the slider's value as necessary
func _on_range_h_slider_drag_ended(value_changed: bool) -> void:
	_range_is_being_dragged = false
	if value_changed:
		if target_node.get(property) is int:
			target_node.set_deferred(property, int(%RangeHSlider.value))
		else:
			target_node.set_deferred(property, %RangeHSlider.value)

## sends the new value to the target node, releases focus because otherwise the button
## will be the UI object in focus and can be toggled with key presses
func _on_toggle_button_toggled(toggled_on: bool) -> void:
	target_node.set_deferred(property, toggled_on)
	%ToggleButton.release_focus()

## calls the method in question and cosmetically edits the button
## to make it obvious it was pressed and avoid accidental double presses
func _on_trigger_button_pressed() -> void:
	target_node.call_deferred(property)
	%TriggerButton.text = "Sent!"
	%TriggerButton.disabled = true
	%TriggerCooldown.start()

## resets the button when the timer is done
func _on_trigger_cooldown_timeout() -> void:
	%TriggerButton.text = "Activate"
	%TriggerButton.disabled = false
